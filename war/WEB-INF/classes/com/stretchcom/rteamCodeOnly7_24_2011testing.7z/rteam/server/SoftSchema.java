package com.stretchcom.rteam.server;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

public class SoftSchema {
	private static final Logger log = Logger.getLogger(SoftSchema.class.getName());
}
